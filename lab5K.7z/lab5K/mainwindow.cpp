#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    no_auto_change = true;
    ui->spinBox->setMaximum(MAX_MAS);
    ui->label_Sum->clear();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_spinBox_valueChanged(int arg1)
{
    ui->tableWidget->setRowCount(arg1);
}

void MainWindow::on_tableWidget_cellChanged(int row, int column)
{
    if(no_auto_change){
        bool fl;
        ui->tableWidget->item(row, column)->text().toInt(&fl);
        if(fl)
            ui->tableWidget->item(row, column)->setBackgroundColor(Qt::white);
        else
            ui->tableWidget->item(row, column)->setBackgroundColor(Qt::red);

    }
}

void MainWindow::on_pushButton_Rand_clicked()
{
    no_auto_change=false;

    int mas[MAX_MAS];
    int mas_size = ui->spinBox->value();

    for(int i=0;i<mas_size;i++)
        mas[i]=rand()%201-100;

    for(int i=0;i<mas_size;i++)
    {
        if (ui->tableWidget->item(i, 0)==nullptr)
        {
            QTableWidgetItem *ti;
            ti = new QTableWidgetItem;
            ui->tableWidget->setItem(i, 0, ti);
        }
        ui->tableWidget->item(i,0)->setText(QString::number(mas[i]));
        ui->tableWidget->item(i,0)->setBackgroundColor(Qt::white);
    }
    no_auto_change=true;
}



void MainWindow::on_pushButton_Sum_clicked()
{
    no_auto_change = false;
    int mas[MAX_MAS];
    int mas_size = ui->spinBox->value();

    bool fl_loc;
    bool fl_gl;

    fl_gl=true;

    for (int i=0;i<mas_size;i++)
    {
        if(ui->tableWidget->item(i, 0)!=nullptr)
        {
            mas[i]=ui->tableWidget->item(i, 0)->text().toInt(&fl_loc);
        }
        else
        {
            fl_loc=false;
            QTableWidgetItem *ti;
            ti = new QTableWidgetItem;
            ui->tableWidget->setItem(i, 0, ti);
        }
        if (fl_loc)
            ui->tableWidget->item(i,0)->setBackgroundColor(Qt::white);
        else {
            ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);
            fl_gl=false;
        }
    }
    int sum=0;
    if(fl_gl)
    {
        for (int i=0;i<mas_size;i++)
        {
            sum+=mas[i];
        }
        if (fl_gl)
            ui->label_Sum->setNum(sum);
        else
            ui->label_Sum->setText("Some errors");
    }
    no_auto_change=true;
}

void MainWindow::on_pushButton_Magic_clicked()
{
    no_auto_change = false;
    int mas[MAX_MAS];
    int mas_size = ui->spinBox->value();

    bool fl_loc;
    bool fl_gl;

    fl_gl=true;

    for (int i=0;i<mas_size;i++)
    {
        if(ui->tableWidget->item(i, 0)!=nullptr)
        {
            mas[i]=ui->tableWidget->item(i, 0)->text().toInt(&fl_loc);
        }
        else
        {
            fl_loc=false;
            QTableWidgetItem *ti;
            ti = new QTableWidgetItem;
            ui->tableWidget->setItem(i, 0, ti);
        }
        if (fl_loc)
            ui->tableWidget->item(i,0)->setBackgroundColor(Qt::white);
        else {
            ui->tableWidget->item(i,0)->setBackgroundColor(Qt::red);
            fl_gl=false;
        }
    }
    if(fl_gl)
    {
        for (int i=0;i<mas_size;i++){
            if(mas[i]%2==0)
                mas[i]=mas[i]+3;
            else
                mas[i]=mas[i]-2;
        }
    }

    if(fl_gl)
    {
        for (int i=0;i<mas_size;i++)
        {
            ui->tableWidget->item(i,0)->setText(QString::number(mas[i]));
        }
    } else
        ui->label_Sum->setText("Some errors");

    no_auto_change=true;
}

